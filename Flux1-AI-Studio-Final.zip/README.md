# Flux1 AI Studio
Demo project for AI tools