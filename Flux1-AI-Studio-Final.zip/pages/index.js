import Link from 'next/link';

export default function Home() {
  return (
    <div style={{padding:'2rem', textAlign:'center'}}>
      <h1>Welcome to Flux1 AI Studio</h1>
      <nav>
        <Link href="/prompt-image">Prompt to Image</Link> |{' '}
        <Link href="/prompt-video">Prompt to Video</Link> |{' '}
        <Link href="/image-to-video">Image to Video</Link>
      </nav>
    </div>
  );
}
